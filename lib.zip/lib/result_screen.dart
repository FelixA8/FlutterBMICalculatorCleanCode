import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result});
  final double result;

  @override
  Widget build(BuildContext context) {
    Color? resultColor;
    String getResult() {
      if (result >= 25) {
        resultColor = Colors.pink;
        return 'Overweight';
      } else if (result > 18.5) {
        resultColor = Colors.green;
        return 'Normal';
      } else {
        resultColor = Colors.yellow;
        return 'Underweight';
      }
    }

    String getInterpretation() {
      if (result >= 25) {
        return 'You have a higher than normal body weight. Try to exercise more.';
      } else if (result >= 18.5) {
        return 'You have a normal body weight. Good job!';
      } else {
        return 'You have a lower than normal body weight. You can eat a bit more.';
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI Calculator'),
        centerTitle: true,
        backgroundColor: const Color(0xFF0A0E21),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15.0),
        child: Column(
          children: [
            const SizedBox(
              height: 50,
            ),
            const Text(
              'Your Result',
              style: TextStyle(fontSize: 60, fontWeight: FontWeight.w900),
            ),
            Expanded(
              flex: 4,
              child: Container(
                margin: const EdgeInsets.all(15),
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0xFF1D1E33),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      getResult(),
                      style: TextStyle(
                          color: resultColor,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 60,
                    ),
                    Text(
                      result.toStringAsFixed(1),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 80,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 60,
                    ),
                    Text(
                      getInterpretation(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w500),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  width: double.infinity,
                  color: Colors.pink,
                  child: const Center(
                    child: Text(
                      'Re-Calculate',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 40, fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
