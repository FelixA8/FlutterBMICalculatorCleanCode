import 'dart:math';

import 'package:flutter/material.dart';
import 'package:my_app/data.dart';
import 'package:my_app/result_screen.dart';
import 'package:my_app/widgets/male_female_widgets.dart';
import 'package:my_app/widgets/slider_widgets.dart';
import 'package:my_app/widgets/weight_age_widgets.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  Gender? currentGender;
  int currentHeight = 180;
  int currentWeight = 180;
  int currentAge = 20;
  void getGender(Gender chosenGender) {
    currentGender = chosenGender;
  }

  void getHeight(int chosenHeight) {
    currentHeight = chosenHeight;
  }

  void getWeight(int chosenWeight) {
    currentWeight = chosenWeight;
  }

  void getAge(int chosenAge) {
    currentAge = chosenAge;
  }

  double CalculateBMI(currentHeight, currentWeight) {
    return currentWeight / pow(currentHeight / 100, 2);
  }

  void goToResultScreen() {
    double result = CalculateBMI(currentHeight, currentWeight);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return ResultScreen(result: result);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI Calculator'),
        centerTitle: true,
        backgroundColor: const Color(0xFF0A0E21),
      ),
      body: Column(
        children: [
          MaleFemaleWidget(
            getGender: getGender,
          ),
          SliderWidgets(getHeight: getHeight),
          WeightAgeWidgets(getWeight: getWeight, getAge: getAge),
          Expanded(
              child: GestureDetector(
            onTap: () {
              goToResultScreen();
            },
            child: Container(
              color: Colors.pink,
              width: double.infinity,
              child: const Center(
                child: Text(
                  'Calculate',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ))
        ],
      ),
    );
  }
}
