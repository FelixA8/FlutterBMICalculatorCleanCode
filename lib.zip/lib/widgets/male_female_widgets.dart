import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:my_app/data.dart';

class MaleFemaleWidget extends StatefulWidget {
  const MaleFemaleWidget({super.key, required this.getGender});
  final void Function(Gender) getGender;

  @override
  State<MaleFemaleWidget> createState() => _MaleFemaleWidgetState();
}

class _MaleFemaleWidgetState extends State<MaleFemaleWidget> {
  Color maleColor = const Color(0xFF1D1E33);
  Color femaleColor = const Color(0xFF1D1E33);

  void onTapMaleButton() {
    if (maleColor == const Color(0xFF111328)) {
      maleColor = const Color(0xFF1D1E33);
    } else {
      femaleColor = const Color(0xFF1D1E33);
      maleColor = const Color(0xFF111328);
      widget.getGender(Gender.male);
    }
  }

  void onTapFemaleButton() {
    if (femaleColor == const Color(0xFF111328)) {
      femaleColor = const Color(0xFF1D1E33);
    } else {
      maleColor = const Color(0xFF1D1E33);
      femaleColor = const Color(0xFF111328);
      widget.getGender(Gender.female);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              onTapMaleButton();
            });
          },
          child: Container(
            margin: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: maleColor,
            ),
            height: 200,
            width: 170,
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  FontAwesomeIcons.mars,
                  size: 80,
                ),
                SizedBox(
                  height: 15,
                ),
                Text(
                  'Male',
                  style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
                ),
              ],
            ),
          ),
        ),
        const Spacer(),
        GestureDetector(
          onTap: () {
            setState(() {
              onTapFemaleButton();
            });
          },
          child: Container(
            margin: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: femaleColor,
            ),
            height: 200,
            width: 170,
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  FontAwesomeIcons.venus,
                  size: 80,
                ),
                SizedBox(
                  height: 15,
                ),
                Text(
                  'Female',
                  style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
