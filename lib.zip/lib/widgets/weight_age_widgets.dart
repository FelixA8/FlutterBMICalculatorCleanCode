import 'package:flutter/material.dart';

class WeightAgeWidgets extends StatefulWidget {
  const WeightAgeWidgets(
      {super.key, required this.getWeight, required this.getAge});
  final void Function(int) getWeight;
  final void Function(int) getAge;

  @override
  State<WeightAgeWidgets> createState() => _WeightAgeWidgetsState();
}

class _WeightAgeWidgetsState extends State<WeightAgeWidgets> {
  int weight = 60;
  int age = 20;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          margin: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xFF1D1E33),
          ),
          height: 200,
          width: 170,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Weight',
                style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
              ),
              Text(
                weight.toString(),
                style:
                    const TextStyle(fontSize: 80, fontWeight: FontWeight.w900),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    padding: const EdgeInsets.symmetric(horizontal: 0),
                    onPressed: () {
                      setState(() {
                        weight--;
                        widget.getWeight(weight);
                      });
                    },
                    icon: const Icon(
                      Icons.remove_circle,
                      size: 50,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  IconButton(
                    padding: const EdgeInsets.symmetric(horizontal: 0),
                    onPressed: () {
                      setState(() {
                        weight++;
                        widget.getWeight(weight);
                      });
                    },
                    icon: const Icon(
                      Icons.add_circle,
                      size: 50,
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
        const Spacer(),
        Container(
          margin: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xFF1D1E33),
          ),
          height: 200,
          width: 170,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Age',
                style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
              ),
              Text(
                age.toString(),
                style:
                    const TextStyle(fontSize: 80, fontWeight: FontWeight.w900),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    padding: const EdgeInsets.symmetric(horizontal: 0),
                    onPressed: () {
                      setState(() {
                        age--;
                        widget.getAge(age);
                      });
                    },
                    icon: const Icon(
                      Icons.remove_circle,
                      size: 50,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  IconButton(
                    padding: const EdgeInsets.symmetric(horizontal: 0),
                    onPressed: () {
                      setState(() {
                        age++;
                        widget.getAge(age);
                      });
                    },
                    icon: const Icon(
                      Icons.add_circle,
                      size: 50,
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
