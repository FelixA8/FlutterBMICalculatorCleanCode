import 'package:flutter/material.dart';

class SliderWidgets extends StatefulWidget {
  const SliderWidgets({super.key, required this.getHeight});
  final void Function(int) getHeight;

  @override
  State<SliderWidgets> createState() => _SliderWidgetsState();
}

class _SliderWidgetsState extends State<SliderWidgets> {
  int height = 180;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color(0xFF1D1E33),
      ),
      height: 200,
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Height',
            style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                height.toString(),
                style:
                    const TextStyle(fontSize: 80, fontWeight: FontWeight.w900),
              ),
              const Text(
                'cm',
                style: TextStyle(color: Color(0xFF8D8E98), fontSize: 18),
              )
            ],
          ),
          Slider(
            value: height.toDouble(),
            min: 120.0,
            max: 220.0,
            onChanged: (value) {
              setState(() {
                height = value.toInt();
                widget.getHeight(height);
              });
            },
          )
        ],
      ),
    );
  }
}
